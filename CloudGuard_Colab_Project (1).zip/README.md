# CloudGuard — Google Colab + Flask

A safe, educational cloud-disaster simulator with an HTML/CSS/JavaScript frontend and a Python Flask backend.

## Included scenarios
1. E-commerce flash-sale overload — simulated scale-out and load balancing.
2. Abnormal traffic / DDoS-like spike — simulated filtering and rate limiting.
3. Application server failure — standby server failover.
4. Banking database failure — replica promotion.
5. Hospital backup failure — SHA-256 verification and restore from newest valid demo backup.
6. Cloud region outage — secondary-region failover.

All infrastructure, traffic, timings and recovery actions are simulated. This app does not connect to or control real websites, cloud accounts, or networks.

## Google Colab setup

Upload/extract the project folder into Colab, or create the files using the provided ZIP.

Cell 1:
```python
%cd /content/CloudGuard
!pip -q install flask
```

Cell 2 — start Flask:
```python
!python app.py > /content/cloudguard.log 2>&1 &
```

Cell 3 — install and start a temporary tunnel:
```python
!npm -q install -g localtunnel
!lt --port 5000
```
Open the HTTPS URL printed by LocalTunnel. If it asks for a tunnel password, follow LocalTunnel's displayed instructions.

If the notebook runtime disconnects, the local server and temporary URL stop. SQLite records persist in the runtime filesystem only while that runtime storage remains available. Download `cloudguard.db` if you need to keep the database.

## Run locally
```bash
pip install flask
python app.py
```
Open http://127.0.0.1:5000

## Notes
- Dashboard baseline telemetry is explicitly simulated.
- RTO values are scenario estimates in seconds, not measured cloud-provider timings.
- RPO is an illustrative recovery-point window in minutes; backup failure updates it based on the selected demo backup age.
- Backup payloads are demo strings. SHA-256 integrity verification is real, but the data itself is not real hospital or customer data.
- DDoS behavior is simulated using request metrics. No attack traffic is generated or sent.
