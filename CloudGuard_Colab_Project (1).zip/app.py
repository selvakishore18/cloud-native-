from flask import Flask, render_template, request, jsonify, send_file
import sqlite3, os, hashlib, random, csv, io
from datetime import datetime, timezone
from threading import Lock

app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), "cloudguard.db")
LOCK = Lock()

SCENARIOS = {
    "ecommerce_overload": {
        "website":"E-commerce website", "title":"Flash sale traffic overload",
        "type":"Server overloading", "severity":"CRITICAL",
        "cause":"A flash sale creates more requests than the primary application tier can safely process.",
        "recommendation":"Scale out application capacity, distribute traffic across healthy instances, and queue excess checkout requests.",
        "strategy":"Auto-scaling + load balancing + request queue",
        "rto":42, "rpo":0, "cpu":98, "ram":91, "rps":20000, "failed":18
    },
    "ddos_traffic": {
        "website":"E-commerce / public website", "title":"Abnormal traffic / DDoS-like spike",
        "type":"Abnormal traffic", "severity":"CRITICAL",
        "cause":"A sudden abnormal request pattern overwhelms the edge and application layers.",
        "recommendation":"Apply rate limits, filter suspicious request patterns, and keep legitimate traffic flowing.",
        "strategy":"Traffic filtering + rate limiting",
        "rto":25, "rpo":0, "cpu":94, "ram":82, "rps":35000, "failed":32
    },
    "server_failure": {
        "website":"Video streaming / enterprise website", "title":"Primary application server failure",
        "type":"Server failure", "severity":"HIGH",
        "cause":"The primary application instance stops responding to health checks.",
        "recommendation":"Remove the failed instance from rotation and route requests to a healthy standby instance.",
        "strategy":"Health-check based server failover",
        "rto":35, "rpo":0, "cpu":0, "ram":0, "rps":1200, "failed":100
    },
    "database_failure": {
        "website":"Online banking website", "title":"Primary database unavailable",
        "type":"Database failure", "severity":"CRITICAL",
        "cause":"The primary database is unavailable; transactions cannot be committed.",
        "recommendation":"Promote a healthy replica after checking replication status, then reconnect application services.",
        "strategy":"Database replica promotion",
        "rto":55, "rpo":2, "cpu":72, "ram":88, "rps":4500, "failed":45
    },
    "backup_failure": {
        "website":"Hospital management website", "title":"Latest backup corrupted or missing",
        "type":"Backup failure", "severity":"CRITICAL",
        "cause":"The newest backup fails integrity verification or is unavailable.",
        "recommendation":"Reject the invalid backup, verify older recovery points, and restore the newest valid copy.",
        "strategy":"Verified backup selection + restore",
        "rto":90, "rpo":30, "cpu":65, "ram":75, "rps":850, "failed":60
    },
    "region_outage": {
        "website":"Cloud-hosted enterprise website", "title":"Primary cloud region outage",
        "type":"Region outage", "severity":"CRITICAL",
        "cause":"The primary region is unreachable, affecting application and data services.",
        "recommendation":"Activate the secondary region, validate its database state, and redirect traffic.",
        "strategy":"Multi-region failover",
        "rto":70, "rpo":5, "cpu":0, "ram":0, "rps":6000, "failed":100
    }
}

def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS incidents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scenario_id TEXT NOT NULL, website TEXT, disaster TEXT, severity TEXT,
            strategy TEXT, rto_seconds REAL, rpo_minutes REAL, availability REAL,
            failed_requests INTEGER, status TEXT, created_at TEXT
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_id INTEGER, event TEXT, details TEXT, created_at TEXT
        )""")
init_db()

# In-memory active simulation state. Each browser session receives an independent
# simulation token; SQLite persists completed incident records.
SESSIONS = {}

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def backup_catalog():
    # Deterministic demo records. SHA-256 is computed from each backup's demo payload.
    records = []
    for name, payload, valid, age in [
        ("backup-2026-11-15-0200", "hospital-records-snapshot-v3", True, 2),
        ("backup-2026-11-14-0200", "hospital-records-snapshot-v2", True, 26),
        ("backup-2026-11-13-0200", "corrupted-payload", False, 50)
    ]:
        digest = hashlib.sha256(payload.encode()).hexdigest()
        if not valid:
            digest = "0000" + digest[4:]  # deliberately mismatched stored checksum
        actual = hashlib.sha256(payload.encode()).hexdigest()
        records.append({"name":name, "age_hours":age, "stored_checksum":digest,
                        "actual_checksum":actual, "valid":digest==actual})
    return records

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/summary")
def summary():
    with db() as con:
        total = con.execute("SELECT COUNT(*) n FROM incidents").fetchone()["n"]
        successful = con.execute("SELECT COUNT(*) n FROM incidents WHERE status='RECOVERED'").fetchone()["n"]
        avg = con.execute("SELECT AVG(rto_seconds) n FROM incidents WHERE status='RECOVERED'").fetchone()["n"] or 0
        active = sum(1 for x in SESSIONS.values() if x.get("status")=="DETECTED")
    return jsonify({"total":total,"successful":successful,"active":active,"avg_rto":round(avg,1)})

@app.route("/api/state")
def state():
    token=request.args.get("token","default")
    sim=SESSIONS.get(token)
    if not sim:
        return jsonify({"status":"IDLE","resources":default_resources(),"incident":None})
    return jsonify(sim)

def default_resources():
    return {
        "Primary App Server":"HEALTHY","Secondary App Server":"STANDBY",
        "Primary Database":"HEALTHY","Database Replica":"STANDBY",
        "Backup Storage":"HEALTHY","Primary Region":"ONLINE","Secondary Region":"STANDBY"
    }

@app.route("/api/simulate", methods=["POST"])
def simulate():
    data=request.get_json(force=True)
    scenario_id=data.get("scenario_id")
    token=data.get("token","default")
    if scenario_id not in SCENARIOS:
        return jsonify({"error":"Unknown scenario"}),400
    cfg=SCENARIOS[scenario_id]
    resources=default_resources()
    if scenario_id=="ecommerce_overload":
        resources["Primary App Server"]="OVERLOADED"
    elif scenario_id=="ddos_traffic":
        resources["Primary App Server"]="UNDER ATTACK"
    elif scenario_id=="server_failure":
        resources["Primary App Server"]="FAILED"
    elif scenario_id=="database_failure":
        resources["Primary Database"]="FAILED"
    elif scenario_id=="backup_failure":
        resources["Backup Storage"]="BACKUP CHECK FAILED"
    elif scenario_id=="region_outage":
        resources["Primary Region"]="OFFLINE"
        resources["Primary App Server"]="OFFLINE"
        resources["Primary Database"]="OFFLINE"
    incident={
        "scenario_id":scenario_id, "website":cfg["website"], "title":cfg["title"],
        "type":cfg["type"], "severity":cfg["severity"], "cause":cfg["cause"],
        "recommendation":cfg["recommendation"], "strategy":cfg["strategy"],
        "estimated_rto":cfg["rto"], "rpo":cfg["rpo"],
        "metrics":{"cpu":cfg["cpu"],"ram":cfg["ram"],"rps":cfg["rps"],
                   "failed_requests":cfg["failed"],"success_requests":max(0,100-cfg["failed"])},
        "status":"DETECTED","resources":resources,"events":[
            {"time":now(),"title":"Scenario injected","detail":cfg["title"]},
            {"time":now(),"title":"Incident detected","detail":cfg["cause"]}
        ], "created_at":now(), "recovery":None
    }
    if scenario_id=="backup_failure":
        incident["backups"]=backup_catalog()
    SESSIONS[token]=incident
    return jsonify(incident)

@app.route("/api/recover", methods=["POST"])
def recover():
    data=request.get_json(force=True)
    token=data.get("token","default")
    incident=SESSIONS.get(token)
    if not incident:
        return jsonify({"error":"Run a scenario first."}),400
    if incident["status"]=="RECOVERED":
        return jsonify(incident)
    sid=incident["scenario_id"]
    resources=incident["resources"]
    recovery_detail=""
    if sid=="backup_failure":
        backups=incident.get("backups",backup_catalog())
        valid=[b for b in backups if b["valid"]]
        if not valid:
            incident["status"]="RECOVERY FAILED"
            incident["events"].append({"time":now(),"title":"Recovery failed","detail":"No verified backup copy was available."})
            return jsonify(incident),409
        chosen=min(valid,key=lambda b:b["age_hours"])
        recovery_detail=f"Rejected corrupted copy; restored {chosen['name']} (age: {chosen['age_hours']} hours)."
        incident["selected_backup"]=chosen["name"]
        incident["rpo"]=chosen["age_hours"]*60
    elif sid=="ecommerce_overload":
        incident["added_servers"]=3
        incident["metrics"]["cpu"]=42
        incident["metrics"]["ram"]=54
        incident["metrics"]["failed_requests"]=2
        incident["metrics"]["success_requests"]=98
        recovery_detail="Added 3 simulated app instances and distributed traffic across 4 healthy instances."
    elif sid=="ddos_traffic":
        incident["metrics"]["rps"]=4200
        incident["metrics"]["cpu"]=48
        incident["metrics"]["failed_requests"]=8
        incident["metrics"]["success_requests"]=92
        recovery_detail="Filtered simulated suspicious requests and applied rate limits to the remaining traffic."
    elif sid=="server_failure":
        resources["Secondary App Server"]="ACTIVE"
        recovery_detail="Removed failed primary instance from rotation and routed traffic to the standby server."
    elif sid=="database_failure":
        resources["Database Replica"]="PROMOTED PRIMARY"
        recovery_detail="Promoted the healthy database replica and reconnected the application."
    elif sid=="region_outage":
        resources["Secondary Region"]="ACTIVE"
        recovery_detail="Activated secondary region and redirected simulated application traffic."
    # General service recovery state
    if sid not in ("server_failure","database_failure","region_outage"):
        resources["Secondary App Server"]="ACTIVE"
    if sid=="backup_failure":
        resources["Backup Storage"]="HEALTHY"
        resources["Primary Database"]="RESTORED"
    if sid=="database_failure":
        resources["Primary Database"]="RESTORED"
    if sid=="region_outage":
        resources["Primary Region"]="OFFLINE (ISOLATED)"
        resources["Secondary Region"]="ACTIVE"
    elif sid=="server_failure":
        resources["Primary App Server"]="FAILED (ISOLATED)"
    else:
        resources["Primary App Server"]="HEALTHY"
    incident["status"]="RECOVERED"
    incident["recovery"]={"detail":recovery_detail,"completed_at":now()}
    incident["metrics"]["availability"]=round(100-(incident["estimated_rto"]/86400*100),3)
    incident["events"].append({"time":now(),"title":"Recovery completed","detail":recovery_detail})
    with LOCK, db() as con:
        cur=con.execute("""INSERT INTO incidents
            (scenario_id,website,disaster,severity,strategy,rto_seconds,rpo_minutes,
             availability,failed_requests,status,created_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (sid,incident["website"],incident["type"],incident["severity"],
             incident["strategy"],incident["estimated_rto"],incident["rpo"],
             incident["metrics"]["availability"],incident["metrics"]["failed_requests"],
             incident["status"],incident["created_at"]))
        incident_id=cur.lastrowid
        for ev in incident["events"]:
            con.execute("INSERT INTO events(incident_id,event,details,created_at) VALUES(?,?,?,?)",
                        (incident_id,ev["title"],ev["detail"],ev["time"]))
        incident["database_id"]=incident_id
    SESSIONS[token]=incident
    return jsonify(incident)

@app.route("/api/history")
def history():
    with db() as con:
        rows=con.execute("SELECT * FROM incidents ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/report.csv")
def report_csv():
    with db() as con:
        rows=con.execute("SELECT * FROM incidents ORDER BY id DESC").fetchall()
    output=io.StringIO()
    writer=csv.writer(output)
    if rows:
        writer.writerow(rows[0].keys())
        for row in rows: writer.writerow(tuple(row))
    else:
        writer.writerow(["No completed incidents"])
    mem=io.BytesIO(output.getvalue().encode("utf-8"))
    mem.seek(0)
    return send_file(mem,mimetype="text/csv",as_attachment=True,download_name="cloudguard_incident_report.csv")

@app.route("/api/backups")
def backups():
    return jsonify(backup_catalog())

if __name__ == "__main__":
    app.run(host="0.0.0.0",port=5000,debug=False)
