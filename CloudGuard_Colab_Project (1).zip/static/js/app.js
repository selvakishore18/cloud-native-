const token = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+Math.random());
let current = null, workloadChart=null, requestChart=null, rtoChart=null, outcomeChart=null;
const $ = id => document.getElementById(id);
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2800)}
function navigate(page){
 document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 $("page-"+page).classList.add("active");
 const names={dashboard:"Overview Dashboard",scenarios:"Website Scenario Simulator",detection:"Incident Detection",recovery:"Intelligent Recovery",infrastructure:"Infrastructure Monitor",backups:"Backup Management",analytics:"Analytics & Reports"};
 $("pageTitle").textContent=names[page];
 if(page==="detection")renderDetection(); if(page==="recovery")renderRecovery(); if(page==="infrastructure")renderInfrastructure(); if(page==="backups")loadBackups(); if(page==="analytics")loadHistory();
}
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opts});const data=await r.json();if(!r.ok)throw new Error(data.error||"Request failed");return data}
async function runScenario(id){
 try{current=await api("/api/simulate",{method:"POST",body:JSON.stringify({scenario_id:id,token})});renderAll();toast("Disaster injected and incident detected.");navigate("detection")}
 catch(e){toast(e.message)}
}
async function executeRecovery(){
 try{current=await api("/api/recover",{method:"POST",body:JSON.stringify({token})});renderAll();toast(current.status==="RECOVERED"?"Recovery completed successfully.":"Recovery failed.");navigate("recovery")}
 catch(e){toast(e.message);if(e.message)renderAll()}
}
function renderDetection(){
 const empty=$("detectionEmpty"),box=$("detectionContent");
 if(!current){empty.hidden=false;box.hidden=true;return}
 empty.hidden=true;box.hidden=false;
 box.innerHTML=`<div class="detail-grid">
 <div class="detail-card"><span class="severity">${esc(current.severity)} SEVERITY</span><h3 style="margin-top:14px">${esc(current.title)}</h3><p><b>Website:</b> ${esc(current.website)}<br><b>Disaster:</b> ${esc(current.type)}<br><b>Status:</b> ${esc(current.status)}</p></div>
 <div class="detail-card"><h3>Root cause analysis</h3><p>${esc(current.cause)}</p><h3>Impact</h3><p>CPU ${current.metrics.cpu}% · RAM ${current.metrics.ram}% · ${current.metrics.rps.toLocaleString()} requests/sec · ${current.metrics.failed_requests}% simulated failed requests</p></div></div>
 <div class="recommend"><h3>Recommended recovery strategy</h3><b>${esc(current.strategy)}</b><p>${esc(current.recommendation)}</p></div>
 <div class="panel"><h3>Incident event timeline</h3>${current.events.map(e=>`<div class="event"><b>${esc(e.title)}</b><small>${esc(e.time)} · ${esc(e.detail)}</small></div>`).join("")}</div>`;
}
function renderRecovery(){
 const empty=$("recoveryEmpty"),box=$("recoveryContent");
 if(!current){empty.hidden=false;box.hidden=true;return}
 empty.hidden=true;box.hidden=false;
 let backup=current.selected_backup?`<p><b>Restored recovery point:</b> ${esc(current.selected_backup)}</p>`:"";
 box.innerHTML=`<div class="recommend"><h3>Recommended action · ${esc(current.strategy)}</h3><p>${esc(current.recommendation)}</p><p><b>Estimated RTO:</b> ${current.estimated_rto} seconds &nbsp; <b>Estimated RPO:</b> ${current.rpo} minutes</p></div>
 <div class="detail-card"><h3>Recovery execution</h3><p>${current.status==="RECOVERED"?"Recovery has completed.":"The incident is waiting for recovery execution."}</p>${backup}${current.recovery?`<p>${esc(current.recovery.detail)}</p>`:""}
 <button class="primary" ${current.status==="RECOVERED"?"disabled":""} onclick="executeRecovery()">${current.status==="RECOVERED"?"✓ Recovery completed":"⚡ Execute recovery"}</button></div>`;
}
function healthClass(v){return /HEALTHY|ACTIVE|ONLINE|RESTORED|PROMOTED/.test(v)?"ok":/STANDBY/.test(v)?"warn":"bad"}
function healthCards(target,resources){
 $(target).innerHTML=Object.entries(resources||{}).map(([k,v])=>`<div class="health-card"><span class="dot ${healthClass(v)}"></span><b>${esc(k)}:</b> ${esc(v)}</div>`).join("");
}
function renderInfrastructure(){
 if(!current){healthCards("infraGrid",{ "Primary App Server":"HEALTHY","Secondary App Server":"STANDBY","Primary Database":"HEALTHY","Database Replica":"STANDBY","Backup Storage":"HEALTHY","Primary Region":"ONLINE","Secondary Region":"STANDBY"});return}
 healthCards("infraGrid",current.resources);
 $("primaryRegion").textContent=current.resources["Primary Region"];
 $("secondaryRegion").textContent=current.resources["Secondary Region"];
}
function renderAll(){
 if(!current)return;
 $("cpu").textContent=current.metrics.cpu+"%";$("ram").textContent=current.metrics.ram+"%";$("rps").textContent=current.metrics.rps.toLocaleString()+" Req/sec";
 $("cpuState").textContent=current.metrics.cpu>85?"↑ Critical":"↑ Stable";
 $("cpuState").className=current.metrics.cpu>85?"bad":"good";
 healthCards("healthGrid",current.resources);
 renderDetection();renderRecovery();renderInfrastructure();refreshSummary();
}
async function refreshSummary(){
 try{const s=await api("/api/summary");$("total").textContent=s.total;$("active").textContent=s.active;$("successful").textContent=s.successful+" Runs";$("avgRto").textContent=s.avg_rto+" sec"}catch(e){}
}
async function refreshState(){
 try{const s=await api("/api/state?token="+encodeURIComponent(token));if(s.incident){current=s;renderAll()}else renderInfrastructure();toast("Infrastructure state refreshed")}catch(e){toast(e.message)}
}
async function loadBackups(){
 try{const b=await api("/api/backups");$("backupTotal").textContent=b.length;$("backupValid").textContent=b.filter(x=>x.valid).length;$("backupInvalid").textContent=b.filter(x=>!x.valid).length;
 $("backupRows").innerHTML=b.map(x=>`<tr><td>${esc(x.name)}</td><td>${x.age_hours} hours</td><td><span class="status-pill" style="${x.valid?"":"background:#fff0f1;color:#c33"}">${x.valid?"VERIFIED":"CORRUPTED"}</span></td><td>${x.valid?"Checksum matches":"Checksum mismatch"}</td></tr>`).join("")}catch(e){toast(e.message)}
}
async function loadHistory(){
 try{const rows=await api("/api/history");$("historyRows").innerHTML=rows.length?rows.map(r=>`<tr><td>${r.id}</td><td>${esc(r.website)}</td><td>${esc(r.disaster)}</td><td>${esc(r.strategy)}</td><td>${r.rto_seconds}s</td><td>${r.rpo_minutes}m</td><td><span class="status-pill">${esc(r.status)}</span></td></tr>`).join(""):`<tr><td colspan="7">No completed incidents yet.</td></tr>`;
 drawAnalytics(rows)}catch(e){toast(e.message)}
}
function drawAnalytics(rows){
 const labels=rows.slice(0,8).reverse().map(r=>r.disaster);
 const vals=rows.slice(0,8).reverse().map(r=>r.rto_seconds);
 if(rtoChart)rtoChart.destroy();if(outcomeChart)outcomeChart.destroy();
 const a=$("rtoChart");if(a)rtoChart=new Chart(a,{type:"bar",data:{labels,datasets:[{label:"RTO seconds",data:vals,backgroundColor:"#4b83e6",borderRadius:5}]},options:{responsive:true,plugins:{legend:{display:false}}}});
 const b=$("outcomeChart");if(b)outcomeChart=new Chart(b,{type:"doughnut",data:{labels:["Recovered"],datasets:[{data:[rows.length],backgroundColor:["#22a879"]}]},options:{plugins:{legend:{position:"bottom"}}}});
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function initCharts(){
 const labels=Array.from({length:12},(_,i)=>`${i*5}m`);
 workloadChart=new Chart($("workloadChart"),{type:"line",data:{labels,datasets:[{label:"CPU %",data:[28,31,30,35,33,37,36,34,32,35,33,32],borderColor:"#3478df",tension:.35},{label:"RAM %",data:[38,39,40,41,42,41,43,42,41,42,41,41],borderColor:"#1ba77a",tension:.35}]},options:{responsive:true,scales:{y:{min:0,max:100}}}});
 requestChart=new Chart($("requestChart"),{type:"doughnut",data:{labels:["Successful","Failed"],datasets:[{data:[96,4],backgroundColor:["#24a879","#e35b67"]}]},options:{plugins:{legend:{position:"bottom"}}}});
}
function refreshDashboard(){
 // These are explicitly simulated baseline telemetry values, not host machine metrics.
 const jitter=(base,spread)=>Math.max(0,Math.min(100,base+(Math.random()*spread-spread/2))).toFixed(1);
 if(!current){$("cpu").textContent=jitter(32,5)+"%";$("ram").textContent=jitter(41,4)+"%";$("rps").textContent=(110+Math.floor(Math.random()*25))+" Req/sec"}
}
initCharts();refreshSummary();refreshDashboard();renderInfrastructure();loadBackups();
setInterval(()=>{refreshDashboard();refreshSummary()},5000);
